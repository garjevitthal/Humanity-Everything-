# LifeGuard AI — Android starter project

This is an Android Studio project for the LifeGuard AI safety-information prototype.

## Included
- Native Android UI built with Kotlin and Jetpack Compose
- Emergency button opens the phone dialer for 112 (the user confirms the call)
- Trusted contact saved locally in app preferences
- SMS alert opens the user's messaging app with a prepared message; it is not sent automatically
- Basic emergency safety guide and checklist
- Hindi/English text toggle

## Build
1. Install Android Studio (a current stable version) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect an Android phone or create an emulator.
5. Press Run to test.

To create a Play Store upload bundle: Build > Generate Signed Bundle / APK > Android App Bundle.
Create and protect your own upload key. Never share the keystore or passwords.

## Important before Play Store release
- This is a prototype, not a certified emergency-response service.
- Test all features on supported devices and Android versions.
- Add a complete privacy policy and accurate Data safety declaration.
- Complete Play Console account, app-content, target API, and store-listing requirements.
- Publishing and account setup should be handled by an eligible adult/guardian where required.
- Do not claim automatic emergency dispatch, medical diagnosis, or continuous monitoring.
- No INTERNET, CALL_PHONE, SEND_SMS, contacts, or location permission is requested by this starter.
