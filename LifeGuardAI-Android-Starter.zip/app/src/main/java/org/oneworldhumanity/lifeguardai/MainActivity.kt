package org.oneworldhumanity.lifeguardai

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LifeGuardApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeGuardApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("lifeguard_local", MODE_PRIVATE) }
    var contact by remember { mutableStateOf(prefs.getString("trusted_contact", "") ?: "") }
    var note by remember { mutableStateOf("Your contact stays on this device.") }
    var hindi by remember { mutableStateOf(false) }

    val title = if (hindi) "LifeGuard AI" else "LifeGuard AI"
    MaterialTheme(colorScheme = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF12344A),
        secondary = androidx.compose.ui.graphics.Color(0xFF18794E),
        error = androidx.compose.ui.graphics.Color(0xFFB3261E)
    )) {
        Scaffold(topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                actions = { TextButton(onClick = { hindi = !hindi }) { Text(if (hindi) "English" else "हिंदी") } }
            )
        }) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (hindi) "● सिस्टम तैयार" else "● SYSTEM READY",
                            color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold)
                        Text(if (hindi)
                            "यह सुरक्षा जानकारी देने वाला प्रोटोटाइप है। यह लोगों की लगातार निगरानी नहीं करता और अपने-आप मदद नहीं बुलाता।"
                        else "This is a safety-information prototype. It does not continuously monitor people or automatically contact emergency services.")
                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:112"))
                                context.startActivity(intent)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) { Text(if (hindi) "🚨 आपातकाल — 112 डायल करें" else "🚨 EMERGENCY — CALL 112") }
                        Text(if (hindi) "आपके फोन का डायलर खुलेगा। कॉल करने से पहले नंबर जाँचें।"
                             else "Your phone dialer opens. Review and confirm the call on your device.")
                    }
                }

                Card {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (hindi) "आपातकालीन संपर्क रिमाइंडर" else "Emergency contact reminder",
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        OutlinedTextField(
                            value = contact, onValueChange = { contact = it },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(if (hindi) "विश्वसनीय व्यक्ति का फोन नंबर" else "Trusted person's phone number") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true
                        )
                        Button(onClick = {
                            val number = contact.trim()
                            if (number.isBlank()) note = if (hindi) "पहले नंबर दर्ज करें।" else "Enter a contact number first."
                            else {
                                prefs.edit().putString("trusted_contact", number).apply()
                                note = if (hindi) "इस डिवाइस पर सेव हो गया।" else "Saved on this device."
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (hindi) "इस डिवाइस पर सेव करें" else "Save on this device")
                        }
                        OutlinedButton(onClick = {
                            val number = contact.trim()
                            if (number.isBlank()) {
                                note = if (hindi) "पहले नंबर दर्ज करें।" else "Enter a contact number first."
                            } else {
                                val sms = Intent(Intent.ACTION_SENDTO).apply {
                                    data = Uri.parse("smsto:${Uri.encode(number)}")
                                    putExtra("sms_body", if (hindi)
                                        "मुझे मदद की आवश्यकता हो सकती है। कृपया जल्द संपर्क करें।"
                                    else "I may need help. Please contact me as soon as possible.")
                                }
                                try { context.startActivity(sms) }
                                catch (_: Exception) { note = if (hindi) "SMS ऐप उपलब्ध नहीं है।" else "No SMS app is available." }
                            }
                        }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (hindi) "SMS संदेश तैयार करें" else "Prepare SMS alert")
                        }
                        Text(note, style = MaterialTheme.typography.bodySmall)
                    }
                }

                Card {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (hindi) "कोई व्यक्ति बेहोश हो तो" else "If someone is unconscious",
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        val steps = if (hindi) listOf(
                            "पास जाने से पहले जगह सुरक्षित है या नहीं देखें।",
                            "प्रतिक्रिया और सामान्य साँस की जाँच करें।",
                            "112 पर कॉल करें और ऑपरेटर के निर्देश मानें।",
                            "यदि सामान्य साँस चल रही है, तो सुरक्षित होने पर रिकवरी पोज़िशन दें।",
                            "यदि सामान्य साँस नहीं है, तो प्रशिक्षित हों तो CPR करें या ऑपरेटर के निर्देश मानें।",
                            "खाना, पानी या दवा न दें।"
                        ) else listOf(
                            "Check that the area is safe before approaching.",
                            "Check for a response and normal breathing.",
                            "Call 112 and follow the emergency operator's instructions.",
                            "If breathing normally, use the recovery position if safe and appropriate.",
                            "If not breathing normally, give CPR only if trained or follow the operator's instructions.",
                            "Do not give food, drink, or medicine."
                        )
                        steps.forEachIndexed { index, step -> Text("${index + 1}. $step") }
                        Text(if (hindi) "बेहोशी मेडिकल इमरजेंसी है। तुरंत पेशेवर मदद लें।"
                             else "Unconsciousness is a medical emergency. Get professional help immediately.",
                            color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.SemiBold)
                    }
                }

                Card {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (hindi) "सुरक्षा चेकलिस्ट" else "Safety checklist",
                            style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        val items = if (hindi) listOf(
                            "आपातकालीन नंबर उपलब्ध रखें।",
                            "अपनी यात्रा की योजना किसी भरोसेमंद व्यक्ति से साझा करें।",
                            "जहाँ संभव हो फोन चार्ज रखें।"
                        ) else listOf(
                            "Keep emergency numbers accessible.",
                            "Share your trip plan with someone you trust.",
                            "Keep your phone charged where possible."
                        )
                        items.forEach { Text("• $it") }
                    }
                }
                Text(if (hindi) "LifeGuard AI · संस्करण 1.0 · प्रोटोटाइप"
                     else "LifeGuard AI · Version 1.0 · Prototype",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
